#!/bin/bash

docker run --rm -d -p 3000:3000 --name=grafana \
  --user "$(id -u)" \
  --volume "$PWD/data:/var/lib/grafana" \
  --volume "$PWD/grafana.ini:/etc/grafana/grafana.ini" \
  -e "GF_FEATURE_TOGGLES_ENABLE=publicDashboards" \
  -e "GF_INSTALL_PLUGINS=grafana-clock-panel, grafana-simple-json-datasource, grafana-athena-datasource, grafana-github-datasource, redis-datasource, grafana-opensearch-datasource" \
  -e "GF_PATHS_LOGS=/var/lib/grafana/log" \
  -e "GF_PATHS_PROVISIONING=/var/lib/grafana/provisioning" \
  -e "GF_SERVER_HTTP_PORT=3000" \
  -e "GF_DATABASE_TYPE=postgres" \
  -e "GF_DATABASE_HOST=192.168.56.30:5432" \
  -e "GF_DATABASE_NAME=grafana_db" \
  -e "GF_DATABASE_USER=grafana" \
  -e "GF_DATABASE_PASSWORD=grafana" \
  -e "GF_PANELS_ENABLE_ALPHA=true" \
  -e "GF_PANELS_DISABLE_SANITIZE_HTML=true" \
  -e "GF_PANELS_ALLOW_EMBEDDING=true"\
  docker.io/grafana/grafana-oss
