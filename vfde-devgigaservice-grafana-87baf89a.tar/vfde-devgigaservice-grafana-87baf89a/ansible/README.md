## terraform & ansible

#### The inventory file should already created by terraform 
###### (if you add some host groups or variables, now you can this)
```
vi inventory/inventory
```

#### source environment
```
source .env
alias
```

#### create ansible environment at managed nodes 
```
_create_ansible_user
```

ansible-playbook p_install_grafana.yml -u ubuntu --key-file ../2_deploy_vm_az1/files/keys/id_rsa
