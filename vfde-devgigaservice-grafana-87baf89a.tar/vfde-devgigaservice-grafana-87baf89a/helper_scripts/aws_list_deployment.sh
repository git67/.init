#!/usr/bin/env bash
#set -euo pipefail
#set -x

######################################################################
# ident         : "@(#)<list_deployment.sh> <1.0>"
# version       : Mi 7. Feb 09:52:56 CET 2024
# dev           : heiko.stein@etomer.com
# env           : Linux 6.5.0-14-generic GNU/Linux
######################################################################
# changelog     :
#
#
######################################################################

# var
PATH="${PATH}:/:/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin"

aws resourcegroupstaggingapi get-resources --tag-filters Key=Deploy,Values=vfde-devgigaservice-grafana-87baf89a --profile=default \
    |jq -r '.ResourceTagMappingList[]|.ResourceARN' \
    |awk -F: '{printf "type: %-20s obj: %-25s\n", $3, $6}' \
    |sort

