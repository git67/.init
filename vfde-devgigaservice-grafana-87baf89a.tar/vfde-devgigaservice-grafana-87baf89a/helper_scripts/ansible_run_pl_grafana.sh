#!/usr/bin/env bash 
#set -euo pipefail
#set -x

# ident "@(#)<> <0.9>"
#
# desc          : <>
# version       : <0.9>
# dev           : <heiko.stein@etomer.com>
#
# changelog:
# ...

# var
PATH="${PATH}:/:/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin"
SILENT=${1:+'>/dev/null 2>&1'}

export HOSTN=$(uname -n)
export USERN=$(whoami|cut -d \\ -f2)

# shell
S_BASEDIR="$(dirname $(realpath $0))"

# python venv
VENVN=".pyv"
VENV="$(cd;pwd)/${VENVN}"

# ansible
A_KEY_DIR="${S_BASEDIR}/../files/keys"
A_PLDIR="${S_BASEDIR}/../ansible"
A_INVDIR="${A_PLDIR}/inventories"
A_INVENTORY="${A_INVDIR}/hosts"
A_PLAYBOOK="p_install_grafana.yml"

# _line <char> 
# z.b _line "#"
_line()
{
	CHAR=${1:-"-"}
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | tr ' ' ${CHAR}
}

_print()
{
	STR=${1:-"undef"}
	printf '\t%s\n' "${STR}"
}

_help()
{
	clear
	[ -f ./README.md ] && cat ./README.md | sed -e '/^`/d' | more
}

# _init <locale>
# z.b. _init "en_US.utf8"
_init()
{
	local LOC=${1:-"C"}
	[ $(locale -a | grep -w "${LOC}")  ] && export LANG="${LOC}"
	trap "_help;exit 1" 2
}

# _create_python_venv <full qualifiedname venv> <pip config source dir> 
# _create_python_venv ${VENV} ${S_PIPDIR}
_create_python_venv()
{
	_print "Erzeuge Python 3 ${VENV} ..."
	
	local VENV=${1:-"NONE"}
        local PIPDIR=${2:-"NONE"}

	python3 -m venv ${VENV}

	_print "Aktiviere Python3 ${VENV} ..."
	source ${VENV}/bin/activate

	if [ ! -f ${PIPDIR}/requirements.pip ] || [ ! -r ${PIPDIR}/requirements.pip ];then
        	_print "Datei requirements.pip nicht vorhanden bzw. nicht lesbar."
        	exit 1
	else
		_print "Installiere ${PIPDIR}/requirements.pip in ${VENV} ..."
		pip install -qUr ${PIPDIR}/requirements.pip
	fi

	_print "Deaktiviere Python3 ${VENV} ..."
	deactivate

	_print "... ok"
}

_run_playbook()
{
	_print "Starte Ansible playbook ${PL} ..."

	local WDIR=${1:-"undef"}
	local PL=${2:-"undef"}
	local INV=${3:-"undef"}
	local GROUP=${4:-"undef"}
	local ARGS=${5:-""}
	#local ARGS=${5:-">/dev/null 2>&1"}
	local CMD=""

	if [ ! -f ${WDIR}/${PL} ]; then
		_print "Playbook ${WDIR}/${PL} nicht vorhanden."
                exit 1
	fi

	if [ -d ${WDIR}/../files/keys ]; then
		chmod 600 ${WDIR}/../files/keys/*
	else
		_print "SSH Keys in ${WDIR}/../files/keys/ nicht vorhanden."
		exit 1
	fi
	
	source ${VENV}/bin/activate

	cd ${WDIR}
	
	CMD="ansible-playbook ${PL} -i ${INV} -e group_name=${GROUP} ${ARGS}"
	eval "${CMD}"

	[ $? != 0 ] && _print "... Fehler bei ${CMD}" && exit 1	

	deactivate

	_print "... ok"
}

# main
[ ! "${-#*i}" == "$-" ] && _print "usage: $(basename ./$0)" && exit 1
clear 

_line "#"

_init "en_US.utf8"

_create_python_venv ${VENV} ${S_BASEDIR}

_run_playbook ${A_PLDIR} ${A_PLAYBOOK} "inventories/grafana-hosts" "grafana_nodes" "-u ubuntu --key-file ../files/keys/id_rsa"

_line

exit 0
