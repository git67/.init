#!/usr/bin/env bash  
#set -x

######################################################################
# ident         : "@(#)<destroy_all.shh> <1.0>"
# version       : Mi 7. Feb 09:52:56 CET 2024
# dev           : heiko.stein@etomer.com
# env           : Linux 6.5.0-14-generic GNU/Linux
######################################################################
# changelog     :
#
#
######################################################################

# var
PATH="${PATH}:/:/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin"

# shell / defaults
S_BASEDIR="$(dirname $(realpath $0))"
export TF_LOG_PATH="../log/terraform.log"
export TF_LOG="INFO"


_line()
{
	CHAR=${1:-"-"}
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | tr ' ' ${CHAR}
}

_error()
{
	STR=${1:-"undef"}
	_line
	printf '\t%s\n' "${STR}"
	_line
}

_print()
{
	STR=${1:-"undef"}
	printf '\t%s\n' "${STR}"
}

# main
[ ! "${-#*i}" == "$-" ] && _help && exit 1

clear 

_line 

cd ${S_BASEDIR}/..

for DIR in $(find $(pwd) -maxdepth 1 -type d -name '[0-9]*' ! -name 'h*' ! -name '.' -print | sort -r)
do
        _print "${DIR}"
        cd ${DIR}
        terraform state list > /dev/null 2>&1
        if [ $? == 0 ]; then
                terraform destroy --auto-approve
        fi

done

_line 

exit 0
