#!/usr/bin/env bash
#set -euo pipefail
#set -x

######################################################################
# ident         : "@(#)<check_ssm_role.sh> <1.0>"
# version       : Mi 7. Feb 09:52:56 CET 2024
# dev           : heiko.stein@etomer.com
# env           : Linux 6.5.0-14-generic GNU/Linux
######################################################################
# changelog     :
#
#
######################################################################

# var
PATH="${PATH}:/:/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin"


_line()
{
        CHAR=${1:-"-"}
        printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | tr ' ' ${CHAR}
}

_error()
{
        STR=${1:-"undef"}
        clear
        _line
        printf '\t%s\n' "${STR}"
        _line
}

_print()
{
        STR=${1:-"undef"}
        printf '\t%s\n' "${STR}"
}

ROLE=$(aws iam list-instance-profiles --query "InstanceProfiles[?InstanceProfileName=='grafana_poc_ssm'].Roles" --profile=default | jq '.[][]|.RoleName'|sed -e 's/\"//g')

[ "grafana_poc_ssm" != "${ROLE}" ] && _error "Rolle grafana_poc_ssm nicht verfügbar bzw. kein Zugriff auf den Account." && exit 1

_line
_print "Rolle grafana_poc_ssm ist verfügbar."
_line

exit 0

