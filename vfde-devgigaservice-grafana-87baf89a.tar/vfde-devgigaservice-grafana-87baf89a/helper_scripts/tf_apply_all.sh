#!/usr/bin/env bash  
set -e
#set -x

######################################################################
# ident         : "@(#)<apply_all.sh> <1.0>"
# version       : Mi 7. Feb 09:52:56 CET 2024
# dev           : heiko.stein@etomer.com
# env           : Linux 6.5.0-14-generic GNU/Linux
######################################################################
# changelog     :
#
#
######################################################################

# var
PATH="${PATH}:/:/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin"
export TF_LOG_PATH="../log/terraform.log"
export TF_LOG="INFO"

# shell / defaults
S_BASEDIR="$(dirname $(realpath $0))"


_line()
{
	CHAR=${1:-"-"}
	printf '%*s\n' "${COLUMNS:-$(tput cols)}" '' | tr ' ' ${CHAR}
}

_error()
{
	STR=${1:-"undef"}
	_line
	printf '\t%s\n' "${STR}"
	_line
}

_print()
{
	STR=${1:-"undef"}
	printf '\t%s\n' "${STR}"
}

# main
[ ! "${-#*i}" == "$-" ] && _help && exit 1

clear 

_line 

cd ${S_BASEDIR}/..

for DIR in $(find $(pwd) -maxdepth 1 -type d -name '[0-9]*' ! -name 'h*' ! -name '.' -print|sort)
do
	_print "${DIR}"
	cd ${DIR}
	terraform init && terraform plan && terraform apply --auto-approve
done


_line 

exit 0
